<?php
$page_title = 'Myntra Online Shopping Website';
include ('includes/header.html');
require_once ('./mysqli_connect.php');
?>
    <a href="product.php"><img src="Images/Myntra.jpg" width="800" height="350" id="floatleft" alt="Myntra Online website"></a>
    <br>
    <a href="product.php"><img src="images/Homepage.jpg" width="800" height="300" id="floatleft" alt="Home page"></a>
    <br>
    <a href="product2.php"><img src="images/Home2.jpg" width="195" height="250" id="floatleft" alt="Home page"></a>
    <a href="product2.php"><img src="images/Home3.jpg" width="205" height="250" id="floatleft" alt="Home page"></a>
    <a href="product2.php"><img src="images/Home4.jpg" width="200" height="250" id="floatleft" alt="Home page"></a>
    <a href="product2.php"><img src="images/Home1.jpg" width="200" height="250" id="floatleft" alt="Home page"></a>
	  
    <?php

include ('includes/footer.html');
?>


