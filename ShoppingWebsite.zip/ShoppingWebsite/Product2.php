<?php
$page_title = 'Myntra shopping website';
include ('includes/header.html');
require_once ('./mysqli_connect.php');
?>
<?php
	// Find top five sales
	$q = 'Select ProductID,Name,Price,Description,ImageFile,LongDescription from product2';
        #echo $q;
	$r = @mysqli_query ($dbc, $q);
	echo '<table align="center" border="1">';
	$count=0;
	// Fetch and print all the records:
	while ($row = mysqli_fetch_array($r, MYSQLI_ASSOC)) {
		if($count==0)
			echo '<tr>';
			$count=(++$count)%2;
			echo '<td align="left"><a href="details2.php?pid=' . $row['ProductID'].'"><img src="Accessories/' .$row['ImageFile'] . '" width="200" hight="250"/></a></td><td align="left">
        <a href="details.php?pid=' . $row['ProductID'].'"> ' . $row['Name'] . '</a><br><br>$'.$row['Price'].'
        <br><br><a href="add_cart.php?pid=' . $row['ProductID'] .'"><img src="Images/addToCart.jpg" " width="150" hight="50" /></a></td>
        ';
			if($count==0)
			    echo '</tr>';
	}
	if($count!=0)
		echo '</tr>';
    echo '</table>'; // Close the table.
	mysqli_free_result ($r);	
	
 // End of p IF.
?>
	
<?php // Include the footer:
include ('includes/footer.html');
?>
