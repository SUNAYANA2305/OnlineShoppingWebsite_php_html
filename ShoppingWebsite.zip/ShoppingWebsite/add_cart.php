<?php
include ('includes/header.html');
if(isset($_GET['pid']) && is_numeric($_GET['pid'])){
   $pid=(int)$_GET['pid'];
   if(isset($_SESSION['cart'][$pid])){
       $_SESSION['cart'][$pid]['Quantity']++;
   }
   else{
       $_SESSION['cart'][$pid]['Quantity']=1;
   }
echo "<td>The item is added to your cart!</td>";
echo '
	</form><p align="left">
	<br /><br /><a href="index.php">Continue Shopping</a><br><br><a href="view_cart.php">View your Cart</a></p>'
    ;
}
else{
echo "<td>Not a valid item!</td>";
}
 // Include the footer:
include ('includes/footer.html');
?>
