<?php # Script 10.4 - #4
// This script retrieves all the records from the users table.
// This new version paginates the query results.

$page_title = 'View all the products';
include('./includes/header.html');
echo '<h1>Listed products</h1>';

require_once ('./mysqli_connect.php');

// Number of records to show per page:
$display = 6;

// Determine how many pages there are...
if (isset($_GET['p']) && is_numeric($_GET['p'])) { // Already been determined.
    
    $pages = $_GET['p'];
    
} else { // Need to determine.
    
    // Count the number of records:
    $q = "SELECT COUNT(ProductID) FROM Product";
    $r = @mysqli_query($dbc, $q);
    $row = @mysqli_fetch_array($r, MYSQLI_NUM);
    $records = $row[0];
    
    // Calculate the number of pages...
    if ($records > $display) { // More than 1 page.
        $pages = ceil ($records/$display);
    } else {
        $pages = 1;
    }
    
} // End of p IF.

// Determine where in the database to start returning results...
if (isset($_GET['s']) && is_numeric($_GET['s'])) {
    $start = $_GET['s'];
} else {
    $start = 0;
}

// Define the query:
$q = "SELECT Name, Price, ProductID AS dr, Description FROM product ORDER BY $order_by LIMIT $start, $display";
$r = @mysqli_query($dbc, $q); // Run the query.

// Table header:
echo '<table width="60%">
<thead>
<tr>
	<th align="left"><strong>Edit</strong></th>
	<th align="left"><strong>Delete</strong></th>
	<th align="left"><strong>Name</strong></th>
	<th align="left"><strong>Price</strong></th>
	<th align="left"><strong>ProductID</strong></th>
</tr>
</thead>
<tbody>
';

// Fetch and print all the records....

$bg = '#eeeeee'; // Set the initial background color.

while ($row = mysqli_fetch_array($r, MYSQLI_ASSOC)) {
    $bg = ($bg=='#eeeeee' ? '#ffffff' : '#eeeeee');
    echo '<tr bgcolor="' . $bg . '">
		<td align="left">' . $row['Name'] . '</td>
		<td align="left">' . $row['Price'] . '</td>
		<td align="left">' . $row['dr'] . '</td>
	</tr>
	';
    
} // End of WHILE loop.

echo '</tbody></table>';
mysqli_free_result($r);
mysqli_close($dbc);

// Make the links to other pages, if necessary.
if ($pages > 1) {
    
    // Add some spacing and start a paragraph:
    echo '<br><p>';
    
    // Determine what page the script is on:
    $current_page = ($start/$display) + 1;
    
    // If it's not the first page, make a Previous link:
    if ($current_page != 1) {
        echo '<a href="view_produts.php?s=' . ($start - $display) . '&p=' . $pages . '">Previous</a> ';
    }
    
    // Make all the numbered pages:
    for ($i = 1; $i <= $pages; $i++) {
        if ($i != $current_page) {
            echo '<a href="view_products.php?s=' . (($display * ($i - 1))) . '&p=' . $pages . '">' . $i . '</a> ';
        } else {
            echo $i . ' ';
        }
    } // End of FOR loop.
    
    // If it's not the last page, make a Next button:
    if ($current_page != $pages) {
        echo '<a href="view_products.php?s=' . ($start + $display) . '&p=' . $pages . '">Next</a>';
    }
    
    echo '</p>'; // Close the paragraph.
    
} // End of links section.

include('./includes/footer.html');
?>