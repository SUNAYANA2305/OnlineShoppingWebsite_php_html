<?php
$page_title = 'Sign Up';
include ('includes/header.html');
// Check if the form has been submitted:
if ($_SERVER['REQUEST_METHOD'] == 'POST') {

	require_once ('./mysqli_connect.php'); // Connect to the db.
		
	$errors = array(); // Initialize an error array.
	
	// Check for a first name:
	if (empty($_POST['First'])) {
		$errors[] = 'You forgot to enter your first name.';
	} else {
		$fn = mysqli_real_escape_string($dbc, trim($_POST['First']));
	}
	
	// Check for a last name:
	if (empty($_POST['Last'])) {
		$errors[] = 'You forgot to enter your last name.';
	} else {
		$ln = mysqli_real_escape_string($dbc, trim($_POST['Last']));
	}
	
	// check for address to ship
	if (empty($_POST['Address'])) {
	    $errors[] = 'You forgot to enter your address.';
	} else {
	    $ad = mysqli_real_escape_string($dbc, trim($_POST['Address']));
	}
	
	// Check for an email address:
	if (empty($_POST['Email'])) {
		$errors[] = 'You forgot to enter your email address.';
	} else {
		$e = mysqli_real_escape_string($dbc, trim($_POST['Email']));
		if(!preg_match('/^[\w.-]+@[\w.-]+\.[A-Za-z]{2,6}$/',$e)){
		   $errors[] = 'Invalid email address.';
			      }

	}
	
	// Check for a password and match against the confirmed password:
	if (!empty($_POST['pass1'])) {
		if ($_POST['pass1'] != $_POST['pass2']) {
			$errors[] = 'Your password did not match the confirmed password.';
		} else {
			$p = mysqli_real_escape_string($dbc, trim($_POST['pass1']));
			if(!preg_match('/^\w{8,}$/',$p)){
			      $errors[] = 'Your password should be at least eight characters.';
			      }
		}
	} else {
		$errors[] = 'You forgot to enter your password.';
	}
		
	if (empty($errors)) { // If everything's OK.
	
		//Check if the user already registered
      $q = "SELECT UserID FROM customers WHERE (Password=SHA2('$p',512) AND Email='$e' )";
		$r = @mysqli_query($dbc, $q);
		$num = @mysqli_num_rows($r);
		if ($num < 1) { // Match was made.
         // Register the user in the database...
		
		   // Make the query:
		   $q = "INSERT INTO customers (First, Last, Address, Email, Password) VALUES ('$fn', '$ln', '$ad', '$e', SHA2('$p',512))";		
		   $r = @mysqli_query ($dbc, $q); // Run the query.
		   if ($r) { // If it ran OK.
		      // Print a message:
            echo '<tr><td><h1>Thank you!</h1>
		      <p>You are now registered. </p><p><br /></p></td></tr>';	
		      
		
		   } else { // If it did not run OK.
			
			   // Public message:
			   echo '<tr><td><h1>System Error</h1>
			   <p class="error">You could not be registered due to a system error. We apologize for any inconvenience.</p>';
			
			   // Debugging message:
			   echo '<p>' . mysqli_error($dbc) . '<br /><br />Query: ' . $q . '</p></td></tr>';
						
		    } // End of if ($r) IF.
		
		    mysqli_close($dbc); // Close the database connection.

		    // Include the footer and quit the script:
		    include ('includes/footer.html');
		    exit();
      }else {
		      echo '<tr><td><p>This user is already in the database!<p></td></tr>';
		}
		
	} else { // Report the errors.
	
		echo '
      <tr><td><h1>Error!</h1>
		<p class="error">The following error(s) occurred:<br />';
		foreach ($errors as $msg) { // Print each error.
			echo " - $msg<br />\n";
		}
		echo '</p><p>Please try again.</p><p><br /></td></tr></p>';
		
	} // End of if (empty($errors)) IF.
	
	mysqli_close($dbc); // Close the database connection.

} // End of the main Submit conditional.
?>



<form method="POST" action="register.php">
			
			<table border="3"  >
				<tr>
					<td>First Name</td>
					<td align="left"><input type="text" name="First" size="31"></td>
				</tr>
				<tr>
					<td>Last Name</td>
					<td align="left"><input type="text" name="Last" size="31"></td>
				</tr>
				<tr>
					<td>Address</td>
					<td align="left"><input type="text" name="Address" size="31"></td>
				</tr>
				<tr>
					<td>Email</td>
					<td align="left"><input type="email" name="Email" size="31"></td>
				</tr>
            <tr>
					<td>Password</td>
					<td align="left"><input type="password" name="pass1" size="31"></td>
				</tr>
				<tr>
					<td>Repeat password</td>
					<td align="left"><input type="password" name="pass2" size="31"></td>
				</tr>
				
				<tr>
				<td><input type="submit" name="submit" value="Register" /></td>
 </td></tr></table>
</form>
	
<?php // Include the footer:
include ('includes/footer.html');
?>
