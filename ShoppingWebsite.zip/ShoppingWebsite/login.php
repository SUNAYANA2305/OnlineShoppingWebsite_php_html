<?php # Script 9.3 - login.php

// This page processes the login form submission.
// Upon successful login, the user is redirected.
// Two included files are necessary.
// Send NOTHING to the Web browser prior to the setcookie() lines!

// Check if the form has been submitted:
if ($_SERVER['REQUEST_METHOD'] == 'POST') {

	// For processing the login:
	require_once ('./login_functions.inc.php');
	
	// Need the database connection:
	require_once ('./mysqli_connect.php');
		
	// Check the login:
	list ($check, $data) = check_login($dbc, $_POST['Email'], $_POST['Password']);
	
	if ($check) { // OK!
			
		// Set the cookies:
		session_start();
		$_SESSION['Email']=$data['Email'];
		$_SESSION['First']=$data['First'];
		
		// Redirect:
		$url = absolute_url ('view_cart.php');
		header("Location: $url");
		exit(); // Quit the script.
			
	} else { // Unsuccessful!

		// Assign $data to $errors for error reporting
		// in the login_page.inc.php file.
		$errors = $data;

	}
		
	mysqli_close($dbc); // Close the database connection.

} // End of the main submit conditional.
$page_title = 'Login';
include ('includes/header.html');

// Print any error messages, if they exist:
if (!empty($errors)) {
	echo '<tr><td><h1>Error!</h1>
	<p class="error">The following error(s) occurred:<br />';
	foreach ($errors as $msg) {
		echo " - $msg<br />\n";
	}
	echo '</p><p>Please try again.</p></td></tr>';
}

// Display the form:
?>

<h1>Login</h1>
<form action="login.php" method="post">
<table border="1">
    <tr>
    <td><label for="Email"><b>Email address</b></label></td>
	<td><input type="Email" name="Email" size="20" maxlength="60" value="<?php if (isset($_POST['Email'])) echo $_POST['Email']; ?>" ><br></td>
	</tr>
	<tr>
	<td><label for="Password"><b>Current Password</b></label></td>
	<td><input type="password" name="Password" size="10" maxlength="20" value="<?php if (isset($_POST['Password'])) echo $_POST['Password']; ?>" ><br></td>
	</table>
	<p><input type="submit" name="submit" value="Login"></p>
</form>


<?php // Include the footer:
include ('includes/footer.html');
?>

